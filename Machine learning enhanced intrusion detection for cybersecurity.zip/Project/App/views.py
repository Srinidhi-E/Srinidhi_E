from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView, PasswordResetView, PasswordChangeView
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.views import View
from django.contrib.auth.decorators import login_required 
from django.contrib.auth import logout as auth_logout
import numpy as np
import joblib
from .forms import RegisterForm, LoginForm, UpdateUserForm, UpdateProfileForm
from .models import NetworkData



def home(request):
    return render(request, 'users/home.html')

@login_required(login_url='users-register')


def index(request):
    return render(request, 'app/index.html')

class RegisterView(View):
    form_class = RegisterForm
    initial = {'key': 'value'}
    template_name = 'users/register.html'

    def dispatch(self, request, *args, **kwargs):
        # will redirect to the home page if a user tries to access the register page while logged in
        if request.user.is_authenticated:
            return redirect(to='/')

        # else process dispatch as it otherwise normally would
        return super(RegisterView, self).dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        form = self.form_class(initial=self.initial)
        return render(request, self.template_name, {'form': form})

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)

        if form.is_valid():
            form.save()

            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}')

            return redirect(to='login')

        return render(request, self.template_name, {'form': form})


# Class based view that extends from the built in login view to add a remember me functionality

class CustomLoginView(LoginView):
    form_class = LoginForm

    def form_valid(self, form):
        remember_me = form.cleaned_data.get('remember_me')

        if not remember_me:
            # set session expiry to 0 seconds. So it will automatically close the session after the browser is closed.
            self.request.session.set_expiry(0)

            # Set session as modified to force data updates/cookie to be saved.
            self.request.session.modified = True

        # else browser session will be as long as the session cookie time "SESSION_COOKIE_AGE" defined in settings.py
        return super(CustomLoginView, self).form_valid(form)


class ResetPasswordView(SuccessMessageMixin, PasswordResetView):
    template_name = 'users/password_reset.html'
    email_template_name = 'users/password_reset_email.html'
    subject_template_name = 'users/password_reset_subject'
    success_message = "We've emailed you instructions for setting your password, " \
                      "if an account exists with the email you entered. You should receive them shortly." \
                      " If you don't receive an email, " \
                      "please make sure you've entered the address you registered with, and check your spam folder."
    success_url = reverse_lazy('users-home')


class ChangePasswordView(SuccessMessageMixin, PasswordChangeView):
    template_name = 'users/change_password.html'
    success_message = "Successfully Changed Your Password"
    success_url = reverse_lazy('users-home')

from .models import Profile

def profile(request):
    user = request.user
    # Ensure the user has a profile
    if not hasattr(user, 'profile'):
        Profile.objects.create(user=user)
    
    if request.method == 'POST':
        user_form = UpdateUserForm(request.POST, instance=request.user)
        profile_form = UpdateProfileForm(request.POST, request.FILES, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Your profile is updated successfully')
            return redirect(to='users-profile')
    else:
        user_form = UpdateUserForm(instance=request.user)
        profile_form = UpdateProfileForm(instance=request.user.profile)

    return render(request, 'users/profile.html', {'user_form': user_form, 'profile_form': profile_form})

Model = joblib.load('D:/final year/ITPML11-FINAL/ITPML11- FINAL CODING/Deploy/Project/App/intrusion.pkl')

def network_data_view(request):
    network_data = NetworkData.objects.all()
    return render(request, 'App/Db.html', {'network_data': network_data})

def model(request):
    if request.method == "POST":
        int_features = [x for x in request.POST.values()]
        int_features = int_features[1:]  # Remove the CSRF token or other non-feature values
        final_features = [np.array(int_features, dtype=object)]
        prediction = Model.predict(final_features)
        output = prediction[0]

        # Prediction and prevention texts
        if output == 0:
            prediction_text = "THE DENIAL OF SERVICE (DOS) ATTACK MIGHT BE OCCUR IN THIS CONDITION"
            prevention_text = ("PREVENTION: Preventing a Denial of Service (DoS) attack involves implementing robust network security measures, "
                            "such as deploying firewalls and intrusion detection/prevention systems. Additionally, regularly updating and patching software vulnerabilities can thwart potential attack vectors. "
                            "Employing rate limiting and traffic filtering mechanisms helps mitigate the impact of sudden, excessive requests, enhancing overall system resilience against DoS threats.")
            precaution_text = ("PRECAUTIONS: Regularly back up critical data and maintain an incident response plan to quickly address and recover from DoS attacks. "
                            "Educate employees about recognizing and reporting suspicious activities. Ensure your ISP has measures in place to handle large traffic volumes.")
        elif output == 1:
            prediction_text = "THE NONE OF ATTACK MIGHT BE OCCUR IN THIS CONDITION. THIS IS NORMAL"
            prevention_text = "PREVENTION: THERE ARE NO NEED PREVENTIONS."
            precaution_text = ("PRECAUTIONS: Continue to follow standard security practices to maintain a secure environment. "
                            "Regularly review and update security policies to adapt to evolving threats. Conduct periodic security training for staff.")
        elif output == 2:
            prediction_text = "THE PROBE ATTACK MIGHT BE OCCUR IN THIS CONDITION"
            prevention_text = ("PREVENTION: Preventing probe attacks involves implementing strong network security practices. Regularly monitoring and analyzing network traffic for anomalous patterns can help detect probes early. "
                            "Additionally, deploying intrusion detection systems and keeping software and systems updated with the latest security patches further fortifies defenses against potential probing activities.")
            precaution_text = ("PRECAUTIONS: Conduct regular security assessments and penetration testing to identify and address vulnerabilities. "
                            "Implement network segmentation to limit the spread of potential intrusions. Ensure employees are trained to recognize and report suspicious activities.")
        elif output == 3:
            prediction_text = "THE REMOTE TO LOCAL (R2L) ATTACK MIGHT BE OCCUR IN THIS CONDITION"
            prevention_text = ("PREVENTION: Preventing Remote-to-Local (R2L) attacks requires securing remote access points. Employing strong authentication mechanisms, such as multi-factor authentication, enhances the security of remote connections. "
                            "Regularly auditing and monitoring access logs for unusual activities helps identify and mitigate potential R2L threats promptly.")
            precaution_text = ("PRECAUTIONS: Limit remote access to only essential personnel and use encrypted communication channels. "
                            "Conduct regular security audits to ensure compliance with security policies. Train employees on secure remote access practices.")
        elif output == 4:
            prediction_text = "THE USER-TO-ROOT (U2R) ATTACK MIGHT BE OCCUR IN THIS CONDITION"
            prevention_text = ("PREVENTION: Mitigating User-to-Root (U2R) attacks involves implementing robust access controls. Employ the principle of least privilege to restrict user permissions, minimizing the impact of potential exploits. "
                            "Regularly update and patch system vulnerabilities to address known security weaknesses, reducing the likelihood of successful U2R attacks. Additionally, continuous monitoring of user activities and behavior can aid in the early detection of suspicious actions, enhancing overall system security.")
            precaution_text = ("PRECAUTIONS: Conduct regular audits of user accounts and permissions to ensure appropriate access levels. "
                            "Implement stringent password policies and encourage the use of strong, unique passwords. Educate users about the risks of social engineering attacks.")

        # Save the prediction result to the database
        prediction_result = NetworkData(
            src_bytes=int_features[0],
            dst_bytes=int_features[1],
            num_failed_logins=int_features[2],
            logged_in=bool(int_features[3]),
            num_compromised=int_features[4],
            root_shell=bool(int_features[5]),
            su_attempted=int_features[6],
            num_root=int_features[7],
            num_file_creations=int_features[8],
            num_shells=int_features[9],
            num_access_files=int_features[10],
            num_outbound_cmds=int_features[11],
            is_host_login=bool(int_features[12]),
            is_guest_login=bool(int_features[13]),
            count=int_features[14],
            srv_count=int_features[15],
            serror_rate=float(int_features[16]),
            srv_serror_rate=float(int_features[17]),
            rerror_rate=float(int_features[18]),
            srv_rerror_rate=float(int_features[19]),
            same_srv_rate=float(int_features[20]),
            diff_srv_rate=float(int_features[21]),
            srv_diff_host_rate=float(int_features[22]),
            dst_host_count=int_features[23],
            dst_host_srv_count=int_features[24],
            dst_host_same_srv_rate=float(int_features[25]),
            dst_host_diff_srv_rate=float(int_features[26]),
            dst_host_same_src_port_rate=float(int_features[27]),
            dst_host_srv_diff_host_rate=float(int_features[28]),
            dst_host_serror_rate=float(int_features[29]),
            dst_host_srv_serror_rate=float(int_features[30]),
            dst_host_rerror_rate=float(int_features[31]),
            dst_host_srv_rerror_rate=float(int_features[32]),
            target=int_features[33],
            predicted_output=output,
            prediction_text=prediction_text,
            prevention_text=prevention_text,
            input_features=str(int_features)
        )
        prediction_result.save()

        return render(request, 'App/output.html', {"prediction_text": prediction_text, "prediction_text1": prevention_text, "precaution_text": precaution_text})
    else:
        return render(request, 'App/model.html')
    
def Basic_report(request):
    return render(request,'App/Basic_report.html')

def Metrics_report(request):
    return render(request,'App/Metrics_report.html')



def logout_view(request):  
    auth_logout(request)
    return redirect('/')