from django.db import models
from django.contrib.auth.models import User
from PIL import Image



# Extending User Model Using a One-To-One Link
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    avatar = models.ImageField(default='default.jpg', upload_to='profile_images')
    bio = models.TextField()

    def __str__(self):
        return self.user.username

    # resizing images
    def save(self, *args, **kwargs):
        super().save()

        img = Image.open(self.avatar.path)

        if img.height > 100 or img.width > 100:
            new_img = (100, 100)
            img.thumbnail(new_img)
            img.save(self.avatar.path)
class NetworkData(models.Model):
    src_bytes = models.IntegerField()
    dst_bytes = models.IntegerField()
    num_failed_logins = models.IntegerField()
    logged_in = models.IntegerField()
    num_compromised = models.IntegerField()
    root_shell = models.IntegerField()
    su_attempted = models.IntegerField()
    num_root = models.IntegerField()
    num_file_creations = models.IntegerField()
    num_shells = models.IntegerField()
    num_access_files = models.IntegerField()
    num_outbound_cmds = models.IntegerField()
    is_host_login = models.IntegerField()
    is_guest_login = models.IntegerField()
    count = models.IntegerField()
    srv_count = models.IntegerField()
    serror_rate = models.FloatField()
    srv_serror_rate = models.FloatField()
    rerror_rate = models.FloatField()
    srv_rerror_rate = models.FloatField()
    same_srv_rate = models.FloatField()
    diff_srv_rate = models.FloatField()
    srv_diff_host_rate = models.FloatField()
    dst_host_count = models.IntegerField()
    dst_host_srv_count = models.IntegerField()
    dst_host_same_srv_rate = models.FloatField()
    dst_host_diff_srv_rate = models.FloatField()
    dst_host_same_src_port_rate = models.FloatField()
    dst_host_srv_diff_host_rate = models.FloatField()
    dst_host_serror_rate = models.FloatField()
    dst_host_srv_serror_rate = models.FloatField()
    dst_host_rerror_rate = models.FloatField()
    dst_host_srv_rerror_rate = models.FloatField()
    target = models.CharField(max_length=100)
    predicted_output = models.IntegerField()
    prediction_text = models.TextField()
    prevention_text = models.TextField()

    input_features = models.TextField()  # Added to store input features

    def __str__(self):
        return f"Prediction ID: {self.id}, Predicted Output: {self.predicted_output}"